﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IlegraChallenge.Business
{
    public static class Constants
    {
        public const string SalesmanId = "001";
        public const string CustomerId = "002";
        public const string SalesId = "003";
    }
}
